package com.example.projetprogmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button monitorBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        monitorBtn = findViewById(R.id.monitor_btn);
        monitorBtn.setOnClickListener(v -> {
            monitorBtn.setText("Ready...");
            Intent runIntent = new Intent(this, MonitorActivity.class);
            runIntent.putExtra("name", "My name");
            startActivity(runIntent);
        });
    }
}