package com.example.projetprogmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Scanner;

public class MonitorActivity extends AppCompatActivity implements View.OnClickListener {

    protected int procId;
    protected int MSG_CALCUL = 1;
    protected Runnable runnable = new Runnable() {
        @Override
        public void run() {
            LinearLayout proclayout = findViewById(R.id.SVLayout);
            final Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
            mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
            final List packageList = getPackageManager().queryIntentActivities(mainIntent, 0);
            String appName;
            String RSS;
            int id;
            for (Object object: packageList) {
                ResolveInfo resolveInfo = (ResolveInfo) object;
                String packageName = resolveInfo.activityInfo.applicationInfo.packageName;
                Log.println(Log.INFO, "PackageName", packageName);
                Process process = null;
                try {
                    process = new ProcessBuilder("ps").start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                assert process != null;
                InputStream inputStream = process.getInputStream();
                Scanner scanner = new Scanner(inputStream);
                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    if (line.startsWith("u0_")) {
                        String[] temp = line.split(" ");
                        String newPackageName = temp[temp.length - 1];
                        if (packageName.equals(newPackageName)) {
                            id = resolveInfo.activityInfo.applicationInfo.uid;
                            if (procId == id) {
                                RSS = temp[temp.length - 5];
                                appName = packageName;
                                String messageString = id + " " + appName + " " + RSS;
                                Message message = messageHandler.obtainMessage(MSG_CALCUL, messageString);
                                messageHandler.sendMessage(message);
                            }
                        }

                    }
                }
            }
            messageHandler.postDelayed(runnable, 5000);
        }
    };

    @SuppressLint("HandlerLeak")
    final Handler messageHandler = new Handler() {
        public void handleMessage(Message message) {
            if (message.what == MSG_CALCUL){
                LinearLayout procLayout = findViewById(R.id.SVLayout);
                String sentMessage = message.obj.toString();
                String[] temp = sentMessage.split(" ");
                Button removeBtn = findViewById(Integer.parseInt(temp[0]));
                TextView removeTextView = findViewById(Integer.parseInt(temp[0])+70000);
                TextView removeTextView_2 = findViewById(Integer.parseInt(temp[0])+140000);
                removeBtn.setVisibility(View.GONE);
                removeTextView.setVisibility(View.GONE);
                removeTextView_2.setVisibility(View.GONE);
                View v = createProcessView(Integer.parseInt(temp[0]), temp[1],temp[2]);
                procLayout.addView(v);
                Toast.makeText(MonitorActivity.this, "RSS updated", Toast.LENGTH_LONG).show();
            }
        }
    };

    private View createProcessView(int UID, String appName, String monitorValue) {
        String  topLeftText, bottomLeftText;
        RelativeLayout relativeLayout = new RelativeLayout(this);
        RelativeLayout.LayoutParams paramsTopLeft = new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT);

        paramsTopLeft.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
        paramsTopLeft.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        RelativeLayout.LayoutParams paramsBottomLeft = new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsBottomLeft.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
        paramsBottomLeft.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
        RelativeLayout.LayoutParams paramsTopRight = new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsTopRight.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
        paramsTopRight.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);

        //topLeftText : [1846] com.google.android.apps.maps
        topLeftText = "[" + UID + "]" + appName;
        //bottomLeftText : RSS: 52356
        bottomLeftText = "RSS:" + monitorValue;
        TextView topLeftTextView = new TextView(this);
        topLeftTextView.setText(topLeftText);
        //la methode setid prend un int, pour cela on utilisera
        // UID + grand nombre pour identifier les texts views
        //Values of UID are up to 65536 IDs
        //ceci est fait poour simplification de code,
        // on pourra créer un tableau pour une correspondance des valeurs...
        topLeftTextView.setId(UID+70000);
        TextView bottomLeftTextView = new TextView(this);
        bottomLeftTextView.setText(bottomLeftText);
        bottomLeftTextView.setId(UID+140000);
        relativeLayout.addView(topLeftTextView, paramsTopLeft);
        relativeLayout.addView(bottomLeftTextView, paramsBottomLeft);
        Button btn = new Button(this);
        btn.setText("Monitor");
        btn.setId(UID);
        relativeLayout.addView(btn, paramsTopRight);
        btn.setOnClickListener(this);

        return relativeLayout;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monitor);
        Intent intent = getIntent();
        intent.getStringExtra("name");
        LinearLayout proclayout = findViewById(R.id.SVLayout);
        // Récupération des informations relatives aux processus
        /*Obtention de la liste des applications installées */
        final Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        final List appsList = getPackageManager().queryIntentActivities(mainIntent, 0);
        String[] appNamesList = new String[appsList.size()];
        int[] Tab_UIDs = new int[appsList.size()];
        String[] Tab_RSSs = new String[appsList.size()];
        int n = 0;
        for(Object object :appsList) {
            ResolveInfo info = (ResolveInfo) object;
            String packageName = info.activityInfo.applicationInfo.packageName;
            Log.println(Log.INFO, "PackageName", packageName);
            //Lancement de la commande système ps
            Process process;
            try {
                process = new ProcessBuilder("ps").start();
            } catch (IOException e) {
                return;
            }
            InputStream in = process.getInputStream();
            Scanner scanner = new Scanner(in);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.startsWith("u0_")) {
                    String[] temp = line.split(" ");
                    String newPackageName = temp[temp.length - 1];
                    //memoire qu’occupe le processus
                    if (packageName.equals(newPackageName)) {
                        appNamesList[n] = packageName;
                        Tab_UIDs[n] = info.activityInfo.applicationInfo.uid;
                        Tab_RSSs[n] = temp[temp.length - 5];
                        View v = createProcessView(Tab_UIDs[n], appNamesList[n], Tab_RSSs[n]);
                        proclayout.addView(v);
                        n++;
                    }
                }
            }
        }
    }

    @Override
    public void onClick(View v) {
        procId = v.getId();
        new Thread(runnable).start();
    }
}